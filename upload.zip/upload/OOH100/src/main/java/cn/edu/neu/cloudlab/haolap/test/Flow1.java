package cn.edu.neu.cloudlab.haolap.test;

import cn.edu.neu.cloudlab.haolap.configuration.CubeConfiguration;
import cn.edu.neu.cloudlab.haolap.socket.JobTestClient;
import org.apache.hadoop.conf.Configuration;

import java.io.IOException;

/**
 * Created by Admin on 6/7/2017.
 */
public class Flow1 {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Configuration configuration= CubeConfiguration.getConfiguration();
        String hostName=configuration.get("fs.default.name");
        System.out.printf(hostName);

    }
}
