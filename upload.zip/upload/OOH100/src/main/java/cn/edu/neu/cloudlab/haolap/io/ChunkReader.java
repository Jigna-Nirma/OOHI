package cn.edu.neu.cloudlab.haolap.io;

import cn.edu.neu.cloudlab.haolap.configuration.CubeConfiguration;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;

/**
 * Created by djagatiya on 12/12/2017.
 */
public class ChunkReader {
    public static void main(String args) throws IOException {
        String URI = args;
        Configuration configuration = CubeConfiguration.getConfiguration();
        FileSystem fs = FileSystem.get(configuration);
        FSDataInputStream fsdi = fs.open(new Path(URI));
        while (fsdi.available() != 0) {
            System.out.println(fsdi.readLong() + "\t" + fsdi.readDouble());
        }
    }
}
