package cn.edu.neu.cloudlab.haolap.mapreduce;

import cn.edu.neu.cloudlab.haolap.application.SelectionCase;
import cn.edu.neu.cloudlab.haolap.util.PathConf;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.List;

/**
 * Created by admin on 7/29/2017.
 */
public class BLCJobCreator {

    final static Logger logger = Logger.getLogger(cn.edu.neu.cloudlab.haolap.mapreduce.HFJobCreator.class);

    public Job createAggregationJob(Configuration conf, long numberOfPages,
                                    List<Long> usedPageNos, String fromCubeIdentifier,
                                    String newCubeIdentifier) throws IOException {
        Job aggregationJob = new Job(conf, "OOH_" + newCubeIdentifier);

        aggregationJob.setMapOutputKeyClass(Text.class);
        aggregationJob.setMapOutputValueClass(DoubleWritable.class);
        aggregationJob.setOutputKeyClass(Text.class);
        aggregationJob.setOutputValueClass(DoubleWritable.class);

        aggregationJob.setMapperClass(BLCMapper.class);
        //aggregationJob.setPartitionerClass(HFPartitioner.class);
        aggregationJob.setReducerClass(HFReducerImpl.class);

        aggregationJob.setInputFormatClass(BLCInputFormat.class);
        aggregationJob.setOutputFormatClass(TextOutputFormat.class);

        // TODO the numberOfReduceTasks can only be int
        aggregationJob.setNumReduceTasks((int) numberOfPages);
//        aggregationJob.setNumReduceTasks(0);

        String inputPathStr = PathConf.getCubeElementPath() + PathConf.getBlockFilePathPrefix();
        String outputPathStr = PathConf.getCubeElementPath()
                + "/OOH_Results/" + newCubeIdentifier + "/";

        for (long l : usedPageNos) {
            FileInputFormat.addInputPath(aggregationJob, new Path(inputPathStr
                    + l));
            //  logger.info(l);
        }

        FileOutputFormat.setOutputPath(aggregationJob, new Path(outputPathStr));

        // aggregationJob.setNumReduceTasks(0);
        // if (!aggregationJob.isSuccessful()) {
        // System.err.println("aggregation job not completed successfully");
        // }
        //
        // Job pageCutingJob = new Job(conf, "HFPageCuting");
        //
        // pageCutingJob.setOutputKeyClass(LongWritable.class);
        // pageCutingJob.setOutputValueClass(DoubleWritable.class);
        return aggregationJob;
    }
}

