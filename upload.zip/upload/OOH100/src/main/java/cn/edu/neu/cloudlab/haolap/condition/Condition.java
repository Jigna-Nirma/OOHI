package cn.edu.neu.cloudlab.haolap.condition;

public interface Condition {

}
