package cn.edu.neu.cloudlab.haolap.application;

import cn.edu.neu.cloudlab.haolap.service.RPCService;
import cn.edu.neu.cloudlab.haolap.service.SchemaServerService;
import org.apache.hadoop.classification.InterfaceAudience;

public final class SchemaServer {
    public static RPCService rpcService;

    public static void main(String argv[]) {

        rpcService = SchemaServerService.getSchemaServerService();
        rpcService.start();


    }
}

