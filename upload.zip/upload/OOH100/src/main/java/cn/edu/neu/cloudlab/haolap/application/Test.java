package cn.edu.neu.cloudlab.haolap.application;

import cn.edu.neu.cloudlab.haolap.RPC.SchemaClient;
import cn.edu.neu.cloudlab.haolap.RPC.SchemaClientInterface;
import cn.edu.neu.cloudlab.haolap.configuration.CubeConfiguration;
import cn.edu.neu.cloudlab.haolap.exception.CubeNotExistsException;
import cn.edu.neu.cloudlab.haolap.exception.SchemaNotExistsException;
import cn.edu.neu.cloudlab.haolap.util.CubeHelper;
import cn.edu.neu.cloudlab.haolap.util.SystemConf;
import org.apache.hadoop.conf.Configuration;

/**
 * Created by marc on 14/12/26.
 */
public class Test {
    public static void main(String[] args) throws CubeNotExistsException, SchemaNotExistsException {

        SchemaClientInterface schemaClient=SchemaClient.getSchemaClient();
        schemaClient.printInfo();
        System.out.println(schemaClient.getSchema(SystemConf.getBaseCubeIdentifier()));

    }
}
