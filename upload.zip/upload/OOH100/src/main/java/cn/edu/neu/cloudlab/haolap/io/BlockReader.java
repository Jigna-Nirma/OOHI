package cn.edu.neu.cloudlab.haolap.io;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Created by admin on 7/30/2017.
 */
public class BlockReader {
    public static void main(String[] args) throws IOException {
        RandomAccessFile file = new RandomAccessFile("F:\\HAOLAP-Test-Case\\Test_100_3_SEG\\CubeElement\\Blocks\\0\\0_0_0_33_33_33.blc", "r");
        long size = file.length();
        int i = 0;
        while (i < size) {
            System.out.println(file.readLong() + ", " + file.readDouble());
            i += 16;
        }

    }
}
