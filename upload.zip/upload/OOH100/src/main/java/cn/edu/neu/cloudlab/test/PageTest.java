package cn.edu.neu.cloudlab.test;

import cn.edu.neu.cloudlab.haolap.RPC.SchemaClient;
import cn.edu.neu.cloudlab.haolap.RPC.SchemaClientInterface;
import cn.edu.neu.cloudlab.haolap.cube.Page;
import cn.edu.neu.cloudlab.haolap.cube.Schema;
import cn.edu.neu.cloudlab.haolap.exception.CubeNotExistsException;
import cn.edu.neu.cloudlab.haolap.exception.SchemaNotExistsException;
import cn.edu.neu.cloudlab.haolap.util.DimensionHelper;
import cn.edu.neu.cloudlab.haolap.util.PageHelper;

import java.util.Arrays;

/**
 * Created by djagatiya on 12/13/2017.
 */
public class PageTest {
    public static void main(String[] args) throws SchemaNotExistsException, CubeNotExistsException {

        SchemaClientInterface schemaClient = SchemaClient.getSchemaClient();
        Schema schema = schemaClient.getSchema("baseCube");
        long numberOfPages = PageHelper.getNumberOfPages(schema);
        long pageLengths[] = PageHelper.getPageLengths(schema);
        long numberOfPageSegmentsInDimension[] = PageHelper
                .getNumberOfPageSegmentsInDimensions(schema);
        long dimensionLengths[] = DimensionHelper.getDimensionLengths(schema);
        System.out.println("numberOfPages:" + numberOfPages);
        System.out.println("dimensionLength "
                + Arrays.toString(dimensionLengths));
        System.out.println("pageLengths:" + Arrays.toString(pageLengths));
        System.out.println("numberOfPageSegmentsInDimension:"
                + Arrays.toString(numberOfPageSegmentsInDimension));

    }
}
