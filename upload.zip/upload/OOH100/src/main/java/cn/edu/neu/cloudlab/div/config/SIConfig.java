package cn.edu.neu.cloudlab.div.config;

/**
 * Created by admin on 7/28/2017.
 */
public class SIConfig {
    public static final int CHUNK_SIZE = 72;
    public static final int KEY_SIZE = 8;
    public static final int VALUE_SIZE = 8;
}
