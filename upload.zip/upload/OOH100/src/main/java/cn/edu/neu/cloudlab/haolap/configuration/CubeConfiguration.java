package cn.edu.neu.cloudlab.haolap.configuration;

import cn.edu.neu.cloudlab.util.ConfigurationLoader;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;

import java.io.File;

/**
 * This class provide a way to get the system's configurations. The
 * configuration files, named "cube-default" and "cube-core.xml" will be loaded
 * into the program.
 *
 * @author Neoh
 * @update Marc
 */
public class CubeConfiguration {
    private static Configuration conf;

    private static Log log = LogFactory.getLog(CubeConfiguration.class);

    private static String hadoopHome = System.getenv("HADOOP_HOME");
    private static String oohHome = System.getenv("OOH_HOME");

    static {

        conf = new Configuration();
        conf.addResource(new Path(hadoopHome + "/etc/hadoop/core-site.xml"));
        conf.addResource(new Path(hadoopHome + "/etc/hadoop/hdfs-site.xml"));
        conf.addResource(new Path(hadoopHome + "/etc/hadoop/mapred-site.xml"));
        conf.addResource(new Path(hadoopHome + "/etc/hadoop/yarn-site.xml"));

        conf.addResource(new Path(oohHome + "/conf/cube-site.xml"));


        System.out.println("HADOOP_HOME = " + hadoopHome);
        System.out.println("OOH_HOME = " + oohHome);
    }

    private CubeConfiguration() {

    }

    private static void addLocalResource(String resourceName) {
        ConfigurationLoader.addLocalResource(conf, resourceName);
    }

    private static void addExteranlResource(String resourceName) {
        ConfigurationLoader.addExteranlResource(conf, resourceName);
    }

    public static Configuration getConfiguration() {
        return conf;
    }

    public static Configuration getCopyOfConfiguration(Configuration conf) {
        return new Configuration(conf);
    }
}
