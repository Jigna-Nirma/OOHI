package cn.edu.neu.cloudlab.haolap.RPC;

import java.io.IOException;

/**
 * Created by admin on 6/10/2017.
 */
public class TestSchemaServer {
    public static void main(String[] args) throws IOException {
        SchemaServer schemaServer=SchemaServer.getSchemaServer();

    }
}
