package cn.edu.neu.cloudlab.experiment.common;

import cn.edu.neu.cloudlab.experiment.util.NodeMonitor;

/**
 * Created by MarcGuo on 5/29/14.
 */
public class EmptyOperator implements NodeMonitorOperation {
    @Override
    public void doOperation(NodeMonitor monitor) {

    }
}
