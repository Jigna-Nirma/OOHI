package cn.edu.neu.cloudlab.haolap.service;

public interface RPCService {
    public void start();

    public void stop();

    public boolean isRunning();
}
