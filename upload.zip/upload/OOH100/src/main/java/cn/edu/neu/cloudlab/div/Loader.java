package cn.edu.neu.cloudlab.div;

import cn.edu.neu.cloudlab.haolap.application.InitializeRandomData;
import cn.edu.neu.cloudlab.haolap.application.Main;
import cn.edu.neu.cloudlab.haolap.application.SchemaServer;
import cn.edu.neu.cloudlab.haolap.application.SelectionCase;
import cn.edu.neu.cloudlab.haolap.exception.*;
import cn.edu.neu.cloudlab.haolap.io.ChunkReader;

import java.io.IOException;

/**
 * Created by admin on 7/30/2017.
 */
public class Loader {
    public static void main(String[] args) throws CubeAlreadyExistsException, SchemaNotExistsException, PageFullException, CubeNotExistsException, PersistErrorException, SchemaAlreadyExistsException, IOException {
        if (args.length > 0) {
            if (args[0].equalsIgnoreCase("load")) {
                Main.main(null);
            } else if (args[0].equalsIgnoreCase("schemaserver")) {
                SchemaServer.main(null);
            } else if (args[0].equalsIgnoreCase("generate")) {
                InitializeRandomData.main(null);
            } else if(args[0].equalsIgnoreCase("job")){
                SelectionCase.main(args,1);
            } else if(args[0].equalsIgnoreCase("job-xml")){
                SelectionCase.main(args,2);
            } else if(args[0].equalsIgnoreCase("util-read")){
                ChunkReader.main(args[1]);
            }

        } else {
            System.out.println("Plz use Cli Args");
        }
    }
}
