package cn.edu.neu.cloudlab.experiment.common;

import cn.edu.neu.cloudlab.experiment.util.NodeMonitor;

/**
 * Created by marc on 5/29/14.
 */
public interface NodeMonitorOperation {
    public void doOperation(NodeMonitor monitor);
}
