package cn.edu.neu.cloudlab;

/**
 * Created by marc on 6/12/14.
 */
public interface ToolsRunner {
    public void run(String[] args) throws Exception;

    public String getName();
}
