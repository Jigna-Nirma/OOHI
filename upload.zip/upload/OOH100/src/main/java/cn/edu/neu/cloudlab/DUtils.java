package cn.edu.neu.cloudlab;

/**
 * Created by admin on 7/27/2017.
 */
public class DUtils {

    byte[] key;
    byte[] value;

    public byte[] getKey() {
        return key;
    }

    public void setKey(byte[] key) {
        this.key = key;
    }

    public byte[] getValue() {
        return value;
    }

    public void setValue(byte[] value) {
        this.value = value;
    }
}
