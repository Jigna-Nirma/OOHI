package cn.edu.neu.cloudlab.haolap.RPC;

public interface ClientInterface {
    public void printInfo();
}
