package cn.edu.neu.cloudlab.haolap.io;

import cn.edu.neu.cloudlab.haolap.configuration.CubeConfiguration;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.MapFile;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.util.ReflectionUtils;

import java.io.IOException;
import java.net.URI;

public class MapFileReader {
    public static void main(String[] args) {
        String uri = "/user/admin/HAOLAP-Test-Case/Test_47616000_72_SEG_MAVEN/CubeElement/OOH_Results/16f33c18a250fb896682dd43aac56c9e/part-r-00000";
        Configuration conf = CubeConfiguration.getConfiguration();
        FileSystem fs = null;
        try {
            fs = FileSystem.get(URI.create(uri), conf);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Path path = new Path(uri);
        MapFile.Reader reader = null;
        try {
            reader = new MapFile.Reader(fs, path.toString(), conf);
            WritableComparable<?> key = (WritableComparable<?>) ReflectionUtils
                    .newInstance(reader.getKeyClass(), conf);
            Writable value = (Writable) ReflectionUtils.newInstance(
                    reader.getValueClass(), conf);
            while (reader.next(key, value)) {
                System.out.println(key + "\t" + value);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
