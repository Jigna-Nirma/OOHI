package cn.edu.neu.cloudlab.haolap.initialize;

import cn.edu.neu.cloudlab.haolap.cube.Dimension;
import cn.edu.neu.cloudlab.haolap.cube.DimensionRange;
import cn.edu.neu.cloudlab.haolap.cube.Level;

import java.util.SortedSet;
import java.util.TreeSet;

/**
 * @author divyesh on 4/7/20
 */
public class SchemaData {

    public static SortedSet<Dimension> getBaseDimensionsTest1() {
        SortedSet<Dimension> dimensions = new TreeSet<Dimension>();
        // 1084752 = 10e5
        dimensions.add(getTimeDimension(1, 6, 31)); // 186
        dimensions.add(getAreaDimension(1, 9, 10)); // 100
        dimensions.add(getDepthDimension(7, 4, 7)); // 196
        return dimensions;
    }

    public static SortedSet<Dimension> getBaseDimensionsTest2() {
        SortedSet<Dimension> dimensions = new TreeSet<Dimension>();
        // 1084752 = 10e5
        dimensions.add(getTimeDimension(1, 12, 31)); // 186
        dimensions.add(getAreaDimension(1, 16, 16)); // 100
        dimensions.add(getDepthDimension(10, 5, 10)); // 196
        return dimensions;
    }

    private static Dimension getTimeDimension(long a, long b, long c) {
        Level level01 = new Level("year", a, 0L, 0);
        Level level02 = new Level("month", b, 0L, 1);
        Level level03 = new Level("day", c, 0L, 2);

        SortedSet<Level> levels = new TreeSet<Level>();
        levels.add(level01);
        levels.add(level02);
        levels.add(level03);
        DimensionRange dimensionRange = new DimensionRange(0L, (a * b * c) - 1L);

        Dimension dimension = Dimension.getDimension("Time", levels, 0,
                dimensionRange);
        return dimension;
    }

    private static Dimension getAreaDimension(long a, long b, long c) {
        Level level01 = new Level("one", a, 0L, 0);
        Level level02 = new Level("oneForth", b, 0L, 1);
        Level level03 = new Level("oneSixteenth", c, 0L, 2);

        SortedSet<Level> levels = new TreeSet<Level>();
        levels.add(level01);
        levels.add(level02);
        levels.add(level03);
        DimensionRange dimensionRange = new DimensionRange(0L, (a * b * c) - 1L);

        Dimension dimension = Dimension.getDimension("Area", levels, 1,
                dimensionRange);
        return dimension;

    }

    private static Dimension getDepthDimension(long a, long b, long c) {
        Level level01 = new Level("50m", a, 0L, 0);
        Level level02 = new Level("10m", b, 0L, 1);
        Level level03 = new Level("1m", c, 0L, 2);

        SortedSet<Level> levels = new TreeSet<Level>();
        levels.add(level01);
        levels.add(level02);
        levels.add(level03);

        DimensionRange dimensionRange = new DimensionRange(0L, (a * b * c) - 1L);
        Dimension dimension = Dimension.getDimension("Depth", levels, 2,
                dimensionRange);
        return dimension;
    }

}
