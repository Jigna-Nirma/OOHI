package cn.edu.neu.cloudlab.haolap.application;

import cn.edu.neu.cloudlab.haolap.exception.*;
import cn.edu.neu.cloudlab.haolap.requestDealer.JobNodeRequestDealer;
import org.dom4j.DocumentException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

public class SelectionCase {

    static String startRange, endRange;

    static int logicType = 0;

    public static void setLogicType(int logicType) {
        SelectionCase.logicType = logicType;
    }

    public static int getLogicType() {
        return logicType;
    }

    //    public static String getJobName() {
//        return "[" + startRange + "]-[" + endRange + "]";
//    }

    public void runJob(String args[]) {
        System.out.println(args.length);
        for (String s : args) {
            System.out.print("<" + s + "> ");
        }
        if (args.length != 3) {
            System.out.println("Required three Args!!");
            System.exit(1);
        }

        int sx, sy, sz, ex, ey, ez;
        startRange = args[0];
        endRange = args[1];
        String logicType = args[2];
        setLogicType(Integer.parseInt(logicType));
        if (startRange.split(",").length < 3 && endRange.split(",").length < 3) {
            System.out.println("Invalid Argument:SX,SY,SZ EX,EY,EZ 1|0");
            System.exit(1);
        }

        String sSplit[] = startRange.split(",");
        String eSplit[] = endRange.split(",");

        sz = Integer.parseInt(sSplit[0]);
        sy = Integer.parseInt(sSplit[1]);
        sx = Integer.parseInt(sSplit[2]);
        ez = Integer.parseInt(eSplit[0]);
        ey = Integer.parseInt(eSplit[1]);
        ex = Integer.parseInt(eSplit[2]);


        String selectTaskXmlStr;
        String timestampStr;
        String fromCubeIdentifier;
        String aggregationTypeStr = "sum";
        Date now = new Date();
        Timestamp timestamp = new Timestamp(now.getTime());
        timestampStr = timestamp.toString();
        fromCubeIdentifier = "baseCube";
        selectTaskXmlStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<properties>" + "<timestamp>"
                + timestampStr
                + "</timestamp>"
                + "<operation>"
                + "<type>select</type>"
                + "<conditions>"
                + "<condition>"
                + "<dimensionName>Time</dimensionName>"
                + "<levelName>day</levelName>"
                + "<start>" + sz + "</start>"
                + "<end>" + ez + "</end>"
                + "</condition>"
                + "<condition>"
                + "<dimensionName>Area</dimensionName>"
                + "<levelName>oneSixteenth</levelName>"
                + "<start>" + sy + "</start>"
                + "<end>" + ey + "</end>"
                + "</condition>"
                + "<condition>"
                + "<dimensionName>Depth</dimensionName>"
                + "<levelName>1m</levelName>"
                + "<start>" + sx + "</start>"
                + "<end>" + ex + "</end>"
                + "</condition>"
                + "</conditions>"
                + "<aggregation>"
                + aggregationTypeStr
                + "</aggregation>"
                + "<from>"
                + fromCubeIdentifier
                + "</from>"
                + "</operation></properties>";

        execute(selectTaskXmlStr, logicType);
    }

    public void runJobXml(String args[]) throws IOException {
        String filePath = args[0];
        String logicType = args[1];
        setLogicType(Integer.parseInt(logicType));
        String selectTaskXmlStr;
        String timestampStr;
        Date now = new Date();
        Timestamp timestamp = new Timestamp(now.getTime());
        timestampStr = timestamp.toString();

        String xmlHeader = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<properties>" + "<timestamp>"
                + timestampStr
                + "</timestamp>";
        String xmlFooter = "</properties>";

        String content = "", line;
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        while ((line = reader.readLine()) != null) {
            content += line;
        }
        selectTaskXmlStr = xmlHeader + content + xmlFooter;
        execute(selectTaskXmlStr, logicType);
    }

    public void execute(String selectTaskXmlStr, String logicType) {
        JobNodeRequestDealer jobNodeRequestDealer = new JobNodeRequestDealer(
                selectTaskXmlStr);
        try {
            jobNodeRequestDealer.deal();
            long start = System.currentTimeMillis();
            if (logicType.equals("1")) {
                System.out.println("NEW Logic");
                jobNodeRequestDealer.runBlockJob();
            } else {
                System.out.println("OLD Logic");
                jobNodeRequestDealer.runJob();
            }
            System.out.println("Time=" + (System.currentTimeMillis() - start));
            //  jobNodeRequestDealer.runBlockJob();
            //jobNodeRequestDealer.cleanCubeDirectory();
            jobNodeRequestDealer.updateToSchemaServer();
        } catch (XmlTypeErrorException e) {
            e.printStackTrace();
        } catch (CubeNotExistsException e) {
            e.printStackTrace();
        } catch (SchemaNotExistsException e) {
            e.printStackTrace();
        } catch (AggregationTypeInvalidException e) {
            e.printStackTrace();
        } catch (CorrespondingDimensionNotExistsException e) {
            e.printStackTrace();
        } catch (CorrespondingLevelNotExistsException e) {
            e.printStackTrace();
        } catch (SizeNotEqualException e) {
            e.printStackTrace();
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InvalidXmlException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SchemaAlreadyExistsException e) {
            e.printStackTrace();
        } catch (CubeAlreadyExistsException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[], int i) throws IOException {
        String[] newArgs = new String[args.length - 1];
        for (int t = 0; t < args.length - 1; t++) {
            newArgs[t] = args[t + 1];
        }
        if (i == 1) {
            new SelectionCase().runJob(newArgs);
        } else if (i == 2) {
            new SelectionCase().runJobXml(newArgs);
        }


    }
}
