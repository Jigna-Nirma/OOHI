package cn.edu.neu.cloudlab.haolap.io;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.util.ReflectionUtils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;

public class SequenceFileReader {
    public static void main(String[] args) throws IOException {
        String uri = "F:/HaoLapTest_100/CubeElement/baseCube/0/data";
        BufferedWriter writer = new BufferedWriter(new FileWriter("F:\\TextInput.txt"));
        Configuration conf = new Configuration();
        FileSystem fs = FileSystem.get(conf);
        Path path = new Path(uri);
        SequenceFile.Reader reader = null;
        try {
            reader = new SequenceFile.Reader(fs, path, conf);
            Writable key = (Writable) ReflectionUtils.newInstance(
                    reader.getKeyClass(), conf);
            Writable value = (Writable) ReflectionUtils.newInstance(
                    reader.getValueClass(), conf);
            /*Text key=new Text();
            DoubleWritable value=new DoubleWritable();
            */
            long position = reader.getPosition();
            while (reader.next(key, value)) {
            /*    String syncSeen = reader.syncSeen() ? "" : "";

                writer.write("[" + position + "]\t" + syncSeen + "\t<"
                        + key + ">\t<" + value + ">");*/
                writer.write(key + "\t" + value);
                //position = reader.getPosition();
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
