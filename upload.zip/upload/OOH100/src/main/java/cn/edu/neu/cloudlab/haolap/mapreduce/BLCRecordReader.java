package cn.edu.neu.cloudlab.haolap.mapreduce;


import cn.edu.neu.cloudlab.haolap.util.SystemConf;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static cn.edu.neu.cloudlab.div.config.SIConfig.KEY_SIZE;
import static cn.edu.neu.cloudlab.div.config.SIConfig.VALUE_SIZE;

/**
 * Created by admin on 7/29/2017.
 */
public class BLCRecordReader extends RecordReader<Text[], DoubleWritable[]> {

    private final String COMMON_SHARE = "/tmp/OOH100/tmp_block_files";
    private Configuration conf;
    RandomAccessFile split;
    //FSDataInputStream split;
    List<Integer> rangeStart;
    List<Integer> rangeEnd;

    Text keys[];
    DoubleWritable values[];
    byte[] buffer;
    /*static int[] rangeStart = new int[]{33, 0, 0};
    static int[] rangeEnd = new int[]{33, 33, 33};*/

    int[] chunkStart;
    int[] chunkEnd;
    int[] sgm = new int[3];

    int SZ, SY, SX;
    int RSZ, RSY, RSX;
    int REZ, REY, REX;
    int CSZ, CSY, CSX;
    int CEZ, CEY, CEX;

    int BSkip = 0;
    int ASkip = 0;
    int Fskip = 0;
    int Dskip = 0;
    int Sskip = 0;
    int Nskip = 0;
    int Ztime = 0;
    int Ytime = 0;

    int i = 0, j = 0;

    int ELEMENT_SIZE = KEY_SIZE + VALUE_SIZE;
    private String blockName[];
    int blockStart;
    int blockEnd;

    File file;
    FileSystem fs;
    Path commonSharePath;

    @Override
    public void initialize(InputSplit inputSplit, TaskAttemptContext taskAttemptContext) throws IOException {
        try {


            this.conf = taskAttemptContext.getConfiguration();
            FileSplit fileSplit = (FileSplit) inputSplit;
            fs = FileSystem.get(this.conf);

            Path fileSplitPath = fileSplit.getPath().getParent();

            String directoryName = fileSplit.getPath().getParent().getName();
            String fileName = fileSplit.getPath().getName();

            String destPath = COMMON_SHARE + "/" + directoryName + "/" + fileName;
            commonSharePath = new Path(COMMON_SHARE + "/" + directoryName + "/");

            file = new File(COMMON_SHARE + "/" + directoryName);
            if (file.exists()) {
                FileUtils.deleteDirectory(file);
            }

            fs.copyToLocalFile(fileSplitPath, commonSharePath);
            // fs.copyToLocalFile();
            //FSDataInputStream in = fs.open(fileSplit.getPath());

            split = new RandomAccessFile(new File(destPath), "r");
            blockName = fileSplit.getPath().getName().split("\\.")[0].split("_");

            chunkStart = new int[]{Integer.parseInt(blockName[0]), Integer.parseInt(blockName[1]), Integer.parseInt(blockName[2])};
            chunkEnd = new int[]{Integer.parseInt(blockName[3]), Integer.parseInt(blockName[4]), Integer.parseInt(blockName[5])};
            getSegmentInfo();

            try {
                initStartAndEndFromHadoopConf();/**TODO*/
            } catch (Exception e) {
                e.printStackTrace();
            }
            inits();
            calc();
            buffer = new byte[(blockEnd - blockStart + 1) * ELEMENT_SIZE];
            split.seek(Fskip * ELEMENT_SIZE);
        } catch (Exception e) {
            throw new IOException("Error While Init.", e);
        }
    }

    private void getSegmentInfo() {
        String[] sgmPart = this.conf.get("sgm").split("_");
        sgm[0] = Integer.parseInt(sgmPart[0]);
        sgm[1] = Integer.parseInt(sgmPart[1]);
        sgm[2] = Integer.parseInt(sgmPart[2]);
    }

    private void inits() {
        RSZ = rangeStart.get(0);
        RSY = rangeStart.get(1);
        RSX = rangeStart.get(2);

        REZ = rangeEnd.get(0);
        REY = rangeEnd.get(1);
        REX = rangeEnd.get(2);

        CSZ = chunkStart[0];
        CSY = chunkStart[1];
        CSX = chunkStart[2];

        CEZ = chunkEnd[0];
        CEY = chunkEnd[1];
        CEX = chunkEnd[2];

        SZ = sgm[0];
        SY = sgm[1];
        SX = sgm[2];
    }

    private void calc() {
        blockStart = Math.max(CSX, RSX);
        blockEnd = Math.min(CEX, REX);

        if (CSX <= RSX)
            BSkip = RSX - CSX;

        if (CEX > REX)
            ASkip = CEX - REX;

        if (CSZ <= RSZ)
            Dskip = (RSZ - CSZ) * SX * SY;

        if (CSY <= RSY) {
            Sskip = (RSY - CSY) * SX;
        }

        if (CEY > REY && CSY <= RSY)
            Nskip = ((CEY - REY) + (RSY - CSY)) * (SX * ELEMENT_SIZE);

        int a, b;

        if (CSZ < RSZ) {
            a = RSZ;
        } else {
            a = CSZ;
        }
        if (CEZ < REZ) {
            b = CEZ;
        } else {
            b = REZ;
        }
        Ztime = b - a + 1;

        if (CSY < RSY) {
            a = RSY;
        } else {
            a = CSY;
        }
        if (CEY < REY) { /**TODO*/
            b = CEY;
        } else {
            b = REY;
        }
        Ytime = b - a + 1;

        Fskip = Dskip + Sskip;
    }

    private void nextBlock() throws IOException {
        split.skipBytes(BSkip * ELEMENT_SIZE);
        split.read(buffer);
        split.skipBytes(ASkip * ELEMENT_SIZE);
        convertElements(buffer);
    }

    private void skipBlock() throws IOException {
        split.skipBytes(Nskip);
    }

    @Override
    public boolean nextKeyValue() throws IOException, InterruptedException {

        if (j < Ytime) {
            nextBlock();
            j++;
            return true;
        } else {
            skipBlock();
            if (i < Ztime - 1) {
                nextBlock();
                i++;
                j = 1;
                return true;
            } else {
                return false;
            }
        }
    }


    private void convertElements(byte[] buffer) {
        keys = new Text[buffer.length / ELEMENT_SIZE];
        values = new DoubleWritable[buffer.length / ELEMENT_SIZE];
        int start = 0;
        int i = 0;
        while (start < buffer.length) {
            keys[i] = new Text(Long.toString(ByteBuffer.wrap(Arrays.copyOfRange(buffer, start, start + KEY_SIZE)).getLong()));
            start += KEY_SIZE;
            values[i] = new DoubleWritable(ByteBuffer.wrap(Arrays.copyOfRange(buffer, start, start + VALUE_SIZE)).getDouble());
            start += VALUE_SIZE;
            i++;
        }
    }

    @Override
    public Text[] getCurrentKey() throws IOException, InterruptedException {
        return keys;
    }

    @Override
    public DoubleWritable[] getCurrentValue() throws IOException, InterruptedException {
        return values;
    }

    @Override
    public float getProgress() throws IOException, InterruptedException {
        return 0;
    }

    @Override
    public void close() throws IOException {
        split.close();
        FileUtils.deleteDirectory(file);
    }

    private void initStartAndEndFromHadoopConf()
            throws Exception {
        String startPointForElementStr = this.conf.get(SystemConf
                .getStartPointForConfSetString());
        String endPointForElementStr = this.conf.get(SystemConf
                .getEndPointForConfSetString());
        if (null == startPointForElementStr
                || startPointForElementStr.equals("")) {
            throw new Exception("start point not set");
        }
        if (null == endPointForElementStr || endPointForElementStr.equals("")) {
            throw new Exception("end point not set");
        }
        rangeStart = new ArrayList<>();
        rangeEnd = new ArrayList<>();
        String tmp[] = startPointForElementStr.split(SystemConf
                .getHadoopConfDelimiter());
        for (String str : tmp) {
            rangeStart.add(Integer.parseInt(str));
        }
        tmp = endPointForElementStr.split(SystemConf.getHadoopConfDelimiter());
        for (String str : tmp) {
            rangeEnd.add(Integer.parseInt(str));
        }
    }

}
