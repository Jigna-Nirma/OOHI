package cn.edu.neu.cloudlab.experiment;

/**
 * Created by marc on 5/29/14.
 */
public class NodeCommandConfiguration {
    public static final String SAR_MONITOR_FILE_NAME = "SAR.txt";
}
