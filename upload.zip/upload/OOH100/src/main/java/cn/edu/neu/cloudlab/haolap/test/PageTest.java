package cn.edu.neu.cloudlab.haolap.test;

import cn.edu.neu.cloudlab.haolap.RPC.SchemaClient;
import cn.edu.neu.cloudlab.haolap.RPC.SchemaClientInterface;
import cn.edu.neu.cloudlab.haolap.cube.Schema;
import cn.edu.neu.cloudlab.haolap.exception.CubeNotExistsException;
import cn.edu.neu.cloudlab.haolap.exception.SchemaNotExistsException;
import cn.edu.neu.cloudlab.haolap.util.PageHelper;

/**
 * Created by admin on 6/17/2017.
 */
public class PageTest {
    public static void main(String[] args) throws CubeNotExistsException, SchemaNotExistsException {

        SchemaClientInterface schemaClient = SchemaClient.getSchemaClient();
        Schema schema = schemaClient.getSchema("baseCube");
        System.out.println(PageHelper.getNumberOfPages(schema));
        long[] longs = PageHelper.getPageLengths(schema);
        System.out.println(longs[0] + "," + longs[1] + "," + longs[2]);
    }
}
